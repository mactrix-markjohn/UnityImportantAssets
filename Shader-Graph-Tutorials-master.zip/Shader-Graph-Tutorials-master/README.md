# Shader Graph Tutorials
Project files for our tutorials on using Shader Graph in Unity.

Contains:

- Fresnel
- Dissolve
- Hologram

Check out our [YouTube Channel](http://youtube.com/brackeys) for more tutorials.

Everything is free to use, also commercially (public domain).