This directory is a temporary staging area for reassembling the native C++ API.

When done, the contents of this folder will be merged into the parent folder,
and replace the existing native wrappers.