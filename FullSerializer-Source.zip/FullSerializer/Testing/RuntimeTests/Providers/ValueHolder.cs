﻿public class ValueHolder<T> {
    public T Value;

    public ValueHolder() { }

    public ValueHolder(T value) {
        Value = value;
    }
}
